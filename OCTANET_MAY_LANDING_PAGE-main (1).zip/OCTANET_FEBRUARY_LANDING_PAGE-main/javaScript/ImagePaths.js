// eslint-disable-next-line no-unused-vars
var imagePaths = [
  "images/hero-image.jpg",
  "images/feature1-image.jpg",
  "images/feature2-image.jpg",
  "images/feature3-image.jpg",
  "images/step1-image.jpg",
  "images/step2-image.jpg",
  "images/step3-image.jpg",
  "images/testimonial1-image.jpg",
  "images/testimonial2-image.jpg",
  "images/cta-image.jpg",
];
