export { default as Hero } from "./Hero.jsx";
export { default as Features } from "./Features.jsx";
export { default as HowItWorks } from "./HowItWorks.jsx";
export { default as Testimonials } from "./Testimonials.jsx";
export { default as CallToAction } from "./CallToAction.jsx";
